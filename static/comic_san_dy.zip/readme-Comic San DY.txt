Inspired by A Legendary Comic Sans MS

Introducing

Comic San DY

A handwriting font made by @Sandylukee

It's a great font for any purpose such as presentation, Article, Magazine, Letter, etc 
especially for fun, young or non-formal theme.

if there is any problems with this font, please email me at sandylukee@gmail.com

to donate click this link : https://paypal.me/sandylukee?locale.x=id_ID

thank you for choosing my Font, hope it will make your design great.


Best Regards
-Sandy Luke-